/**
 * 
 */
package project;

import java.awt.event.ActionEvent;

import javax.swing.JFrame;

/**
 * @author dmaldonado
 *
 */
public class MenuListener extends Menu
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		JFrame frame = new JFrame("Start");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		StartPanel panel = new StartPanel();
		frame.getContentPane().add(panel);

		frame.pack();
		frame.setVisible(true);	
	}

	@Override
	protected void button() 
	{
		System.out.println("Polymorphism through inheritance");
	}
	
	
}
