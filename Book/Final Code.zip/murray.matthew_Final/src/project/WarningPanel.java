/**
 * 
 */
package project;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * @author dmaldonado
 *
 */
public class WarningPanel extends JPanel
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel warning;
	private JButton button;
	
	public WarningPanel()
	{
		setPreferredSize(new Dimension(500,200));
		warning = new JLabel("This is a study guide for CSC 150. This is not meant to replace the class.");
		button = new JButton("Enter");
		button.setBounds(10,10,100,25);
		button.addActionListener(new MenuListener());
		add(warning);
		add(button, BorderLayout.CENTER);
	}
}
