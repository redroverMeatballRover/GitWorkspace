/**
 * 
 */
package project;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

/**
 * @author dmaldonado
 *
 */
public abstract class Menu extends JPanel implements ActionListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public abstract void actionPerformed(ActionEvent e);
	
	
	protected abstract void button();
}