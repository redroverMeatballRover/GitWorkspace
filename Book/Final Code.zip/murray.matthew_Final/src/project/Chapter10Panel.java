/**
 * 
 */
package project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

/**
 * @author dmaldonado
 *
 */
public class Chapter10Panel extends JPanel 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static JTabbedPane study;
	private static JPanel main;
	private static JPanel home, section1, section2, section3, section4, section5, section6, quiz;
	private static JTextArea textArea;
	private static Scanner text;

	public Chapter10Panel()
	{
		setPreferredSize(new Dimension(1000,800));
		study = new JTabbedPane();
		main = new JPanel();
		setSize(800,800);
		main.setBackground(Color.gray);
		study.setForeground(Color.blue);

		main.setLayout(new BorderLayout());

		createPages();

		study= new JTabbedPane();
		study.addTab("Home", home);
		study.addTab("Intro to Exceptions", section1);
		study.addTab("Uncaught Exceptions", section2);
		study.addTab("Try and catch this", section3);
		study.addTab("More Exceptions", section4);
		study.addTab("Exception Class Hierarchy", section5);
		study.addTab("I/O Exceptions", section6);
		study.addTab("Quiz", quiz);
		main.add(study, BorderLayout.CENTER);
		add(main);
		setVisible(true);

	}

	public static void createPages()
	{
		home();
		section1();
		section2();
		section3();
		section4();
		section5();
		section6();
		quiz();
	}

	public static void home()
	{
		home = new JPanel();
		JButton button = new JButton("Menu");
		button.addActionListener(new MenuListener());
		home.add(button); 
	}

	public static void section1()
	{
		section1 = new JPanel();
		textArea = new JTextArea("  Coding problems that arise in a Java program may generate exceptions or errors. Exception- an object that defines an unusual or invalid proccessing. Exceptions are\n" +
								 "  predefined and can be caught and handled. An error is similar to an exception, except that the situation is unrecoverable and it shouldn't be caught. Java, trying\n" +
								 "  to be nice, predefined common exceptions and errors that could happen while running a program. If this isn't good enough for you, you can make your own exceptions.\n" +
								 "  Some examples of situations that will produce exceptions:\n\n" +
								 "  - attempting to divide by zero\n" +
								 "  - an array index that is out of bounds a specified file that could not be found\n" +
								 "  - a requested I/O operation that could not be completed normally\n" +
								 "  - attempting to follow a null reference\n" +
								 "  - attempting to execute an operation that violates some kind of security measure.\n\n" +
								 "     The name of the exception says a lot about the sitution in which the exception occurs. Some exceptions are just a stupid programer error, while others are\n"+
								 "  out of the programmer's hands. Some exceptions are come from a wrong situation, while others occur in unusual conditions.", 70, 70);
		textArea.setBounds(0, 0, 600, 600);
		textArea.setEditable(false);
		section1.add(textArea);
	}

	public static void section2()
	{
		section2 = new JPanel();
		textArea = new JTextArea("  If an exception goes unhandeled, the program will terminate when it hits the exception and a message in red will be produced. The first line will tell you what" +
								 "  happened,\n  including the exception that occured and why it occured. The rest of the message is called a stack trace. It states where the exception occured.\n" +
								 "  Depending on where the exception originated, the stack trace can be one or more lines long. The first trace line indicates the method, file, and line number\n" +
								 "  where the exception occurred. The other trace lines, if present, indicate the methods that were called to get to the method that produced the exception.", 70, 70);
		textArea.setBounds(0, 0, 600, 600);
		textArea.setEditable(false);
		section2.add(textArea);
	}

	public static void section3()
	{
		section3 = new JPanel();
		textArea = new JTextArea("Chapter 7 and stuff", 70, 70);
		textArea.setBounds(0, 0, 600, 600);
		textArea.setEditable(false);
		section3.add(textArea);
	}

	public static void section4()
	{
		section4 = new JPanel();
		textArea = new JTextArea("Chapter 8 and stuff", 70, 70);
		textArea.setBounds(0, 0, 600, 600);
		textArea.setEditable(false);
		section4.add(textArea);
	}

	public static void section5()
	{
		section5 = new JPanel();
		textArea = new JTextArea("Chapter 9 and stuff", 70, 70);
		textArea.setBounds(0, 0, 600, 600);
		textArea.setEditable(false);
		section5.add(textArea);
	}

	public static void section6()
	{
		section6 = new JPanel();
		textArea = new JTextArea("Chapter 10 and stuff", 70, 70);
		textArea.setBounds(0, 0, 600, 600);
		textArea.setEditable(false);
		section6.add(textArea);
	}
	
	public static String read(String file)
	{
		String chap = "";
		try {
			text = new Scanner(new File(file));
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} finally {
			System.out.println("Searches for text document to fill text area");
		}
		while(text.hasNext())
		{
			chap = chap + text.nextLine() + "\n";
			
		}
		return chap;
	}

	public static void quiz()
	{
		quiz = new JPanel();
		JButton button = new JButton("Take Quiz");
		button.addActionListener(new Listener());
		quiz.add(button);
	}	
}
	
	class Listener implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent arg0) 
		{
			JFrame frame = new JFrame("Style Options");
			
			frame.getContentPane().add(new StyleOptionsPanel());
			 
			frame.pack();
			frame.setVisible(true);
		}
		
	}